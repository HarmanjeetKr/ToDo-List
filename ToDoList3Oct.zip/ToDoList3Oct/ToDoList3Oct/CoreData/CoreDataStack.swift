//
//  CoreDataStack.swift
//  ToDoList3Oct
//
//  Created by Harjinder on 2018-10-08.
//  Copyright © 2018 Harmanjeet. All rights reserved.
//

import Foundation
import CoreData

class CoreDataStack{
    var container: NSPersistentContainer
    {
        let container = NSPersistentContainer(name: "ToDos")
        container.loadPersistentStores { (description, error) in
            guard error == nil else{
                print("Error: \(error!)")
                return
            }
        }
        return container
    }
    
    var managedContext: NSManagedObjectContext{
        return container.viewContext
    }
}
